/*
**** REMEMBER TO SET THE WORKING DIRECTORY *****
This script is meant to go through data file in R and separate genes with a certain P-value
Created by Kathryn Kananen on 5/30/16
*/

// reads data
mydata = read.csv("DE_total_low_exp.csv")  

// searches for value at certain range at specified location
newData = subset(mydata, (padj.teo < .05 & padj.teo >.01) | (padj.maize < .05 & padj.maize > .1))

// writes out the document 
write.csv(newData, file = "test.csv", row.names = FALSE, na = "NA")

/*
The file named "new_DE_low_exp" was created with the vales of maize and teosinte <= .05
The file named "newRanged_DE_low_exp" was created with the values given above in the script
/*