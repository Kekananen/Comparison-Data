"""""
This script was made to go through the file created by the zeaGenePopFormatter
and sort the Hybrid populations, mexicana populations, and parv populations of
high confidence into seperate files based on input from bash file.  
Created by Kathryn Kananen on 9/2/17
"""""
import sys

zeaAllPop_DIYABC = open(sys.argv[1]) #File generated form the zeaGenePopFormatter.py
out = open(sys.argv[2],'w') #Varies but will always have Run.snp in it

# Given by the bash script made from the CombGenDIYABC.py
hybridPopName = sys.argv[3]
parvPopName = sys.argv[4]
mexPopName = sys.argv[5]

for line in zeaAllPop_DIYABC:
    if not line.startswith("Test") and not line.startswith("IND"):   
        indivDIYABC = line.strip().split("   ")
        accession = indivDIYABC[2]

        if accession.startswith(hybridPopName):
            out.write(line)
        if accession.startswith(parvPopName):
            out.write(line)    
        if accession.startswith(mexPopName):
            out.write(line)
    else:
         out.write(line)
         
         
zeaAllPop_DIYABC.close()
out.close()       