#!/bin/bash

python ~/Documents/Hufford/Hufnagel/Test/HybridData.py DIYABC.out HCB_ZMP_ZMXRun.snp HCB ZMP ZMX
python ~/Documents/Hufford/Hufnagel/Test/HybridData.py DIYABC.out HCP_ZMP_ZMXRun.snp HCP ZMP ZMX
python ~/Documents/Hufford/Hufnagel/Test/HybridData.py DIYABC.out HSG_ZMP_ZMXRun.snp HSG ZMP ZMX
