"""""
This script is designed to remove information from the Genotypes file
The information is stored into a dictionary and then scans the bigInfoFile 
and seperates the the individauls by acession, check the confidence 
intervals, and then create a new list of those individuals
Created by Kathryn Kananen on 9/8/16
"""""
"""
Very nice description!  I can see that you've gotten much better with
annotation!  One thing that is slightly off about the description is that we 
want populations(accessions) in the end instead of individuals as it says above
--DEH
""" 


import sys

filteredRaces = open(sys.argv[1]) #genotypes_filtered.races
ZeaAllInfo = open(sys.argv[2]) #ZeaAllInfo.14col.noMML
mexOut = open(sys.argv[3], 'w') #mexOut.txt
parvOut = open(sys.argv[4], 'w') #parvOut.txt



"""I think your part 1 should work perfectly, but I have some ideas for how it 
could be cleaner code.  BTW Thanks again for annotating well! --DEH"""
###### Part 1 ###### 
# Holds the name of individuals in the population group such as North_Balsas.
# Should be used to get the race name of the individual.
filteredGenoDict = {}

# Uses a counter to get single information points out of filtered file by checking
# if the counter is at a certain point and grabbing information at the value 
# (index) of the counter.  Adds values to Dictionary.
count = 0
for line in filteredRaces:
	outRace = "" # Individuals race
	outIndiv = "" # Individuals name
	usable = line.split("\t")
      #"""Your counter should start here so it resets with each line in the input file --DEH """
      #"""The stuff below could be done easier with indexing.  Ex: outIndiv = usable[1] --DEH"""
	for value in usable:
		# If count is index 1 than value is individuals' name.
		if count == 1:
			indiv = value.strip("\n") #"""Two variables are used here (on this line and the next), but only one is needed --DEH """
			outIndiv = indiv

		# If count is 3 than value is the race only if race is ZMPBA or ZMXCP.
		if count == 3:
			race = value.strip("\n") #"""Two variables are used here (on this line and the next), but only one is needed --DEH """
			outRace = race
                # """This counter below is not needed if its instantiated where I suggested above --DEH"""
			count = 0 # Counter should not count past 3.

		count = count + 1
	filteredGenoDict.update({outIndiv:outRace}) #Add values to dictionary
	

"""Part 2 probably also works perfectly but could be cleaner.  Nice work! --DEH"""
###### Part 2 ######
# Holds information of each accession with high confidence individuals to look
# like >>> accession:[[name,race,conf],[name,race,conf],[name,race,conf]] where
# each list is an individual value.
finalDict = {}

"""these lists aren't used, so they are not needed --DEH"""
accessionLST = []
growingLST = []
finalLST = []
for info in ZeaAllInfo:
	# Ignore the title line
	if not info.startswith("#"):
		allInfoLine = info.split("\t")

		#Gets all necessary information from ZeaAllInfo file
		name = allInfoLine[0]
		tax = allInfoLine[1]
		accession = allInfoLine[2]
		hybrid = allInfoLine[3]
		zone = allInfoLine[4]  #"""This variable can be deleted as well, it's not used --DEH """

		race = filteredGenoDict[name] # individuals name from filteredGenoDict
#  		Excludes all non parv of mex individuals		

		if(tax == "Zea_mays_parviglumis" or tax == "Zea_mays_mexicana"):
			allInfo = "%s,%s,%s" % (name, race, hybrid)
                # """How you've set allInfo will work, but it would be simpler 
                 #to make and use if you put them in a list or tuple instead of
                 #a string --DEH"""

			if accession not in finalDict:
				finalDict[accession] = [allInfo,]
			else:
				finalDict[accession].append(allInfo)	
								

"""There are some functional issues here.  Also you should set variables with 
reasonable nomes to the names, races, and hybridization-related info --DEH"""
###### Part 3 ######
# Checks to see if a group has a value that is a hybrid or not available and outputs 
# that group to a new file. Uses lists to cross reference each other.
goodPop = []
badPop = [] #"""We only need the good pops really --DEH"""
for key, value in finalDict.items():
        splitValue = value[0].split(",")
        newValue = splitValue[2]

        if newValue == "mexHC" or newValue == "parvHC":
            goodPop.append(key + "\t" + newValue + "\n")

            #"""If you're outputting newValue[2] here already you don't need the info in multiple output files --DEH"""
            if newValue == "mexHC":
                mexOut.write(key + "\n")
            if newValue == "parvHC":
                parvOut.write(key + "\n")

filteredRaces.close()
ZeaAllInfo.close()		
parvOut.close()
mexOut.close()