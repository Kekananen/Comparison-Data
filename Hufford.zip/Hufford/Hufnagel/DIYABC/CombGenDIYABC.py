"""
This script creates a bash script to run the HybridData script by looking 
through the parv, mex and hybrid data files and combining all possible 
combinations of the three into a bash format output.
Created by Kathryn Kananen on 9/2/17
Updated by Kathryn Kananen on 20/2/17
"""
import sys

dataFile = open(sys.argv[1]) #file from ZeaGenePopFormatter.py
out = open(sys.argv[2], 'w') #Bash script to be made

# gathers all information on desired populations into the LSTs
parentLST = ["ZMX","ZMP"]
hybridLST = ["HCB", "HCP", "HSG"]

outLine = ""           
template = ("python ~/Documents/Hufford/Hufnagel/DIYABC/HybridData.py " +
            "DIYABC.snp ")
# makes an output for the bash file based on            
for hybrid in hybridLST:
    outFile = hybrid + "_ZMP_ZMXRun.snp "
    outLine = template + outFile + hybrid + " ZMP ZMX\n"
           
    out.write(outLine)     