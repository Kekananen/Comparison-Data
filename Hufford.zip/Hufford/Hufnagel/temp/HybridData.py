"""""
This script was made to go through the file created by the zeaGenePopFormatter
and sort the Hybrid populations, mexicana populations, and parv populations of
high confidence into seperate files based on input from bash file.  
Created by Kathryn Kananen on 9/2/17
"""""
import sys

zeaAllPop_DIYABC = open(sys.argv[1]) #File generated form the zeaGenePopFormatter.py
out = open(sys.argv[2],'w') #Varies but will always have Run.snp in it

# Given by the bash script made from the CombGenDIYABC.py
hybridPopName = sys.argv[3]
parvPopName = sys.argv[4]
mexPopName = sys.argv[5]

for line in zeaAllPop_DIYABC:
    if not line.startswith("Test") and not line.startswith("IND"):   
        indivDIYABC = line.strip().split("   ")
        accession = indivDIYABC[2]
        if accession == hybridPopName or accession == parvPopName or accession == mexPopName:
            out.write(line)
            
        
        

#hybridLST = [] #holds list of hybrids to look for excluding repeats
#for hybrid in hybridHC:
#    if not hybrid.startswith("#"):
# 
#       hybridIndiv = hybrid.strip().split("\t") 
#       hybridAccession = hybridIndiv[1]
#       if not hybridAccession in hybridLST:
#           hybridLST.append(hybridAccession)
#       
#parvLST = [] #holds list of parv to look for excluding repeats
#count = 0 #only want those chosen as relivent by FST results
#for parv in parvHC:
#    if not parv.startswith("#"):
#        
#        parvIndiv = parv.strip().split("\t")
#        parvAccession = parvIndiv[0]
#        
#        #Only takes first 8 values in the parv file
#        if not parvAccession in parvLST:
#            if count <8:
#                parvLST.append(parvAccession)
#                count +=1
#       
#mexLST = [] #holds list of mex to look for excluding repeats
#for mex in mexHC:
#    if not mex.startswith("#"):
#        
#        mexIndiv = mex.strip().split("\t")
#        mexAccession = mexIndiv[0]
#        if not mexAccession in mexLST:
#           mexLST.append(mexAccession)
#           
#outHybridLST = [] #For out lines for hybrids
#outParvLST = [] #For out lines for Parv
#outMexLST = [] #For out lines for mex
##gets lines previously converted into proper format into location with 
##desired other lines via comparing the populations and placing the line in LST
#for line in zeaAllPop_DIYABC:
#    if not line.startswith("Test") and not line.startswith("IND"):   
#        indivDIYABC = line.strip().split("\t")        
#        popInfo = indivDIYABC[0].strip().split("&")
#        indivAccession = popInfo[1]       
#
#        for hybridAccession in hybridLST:
#           if hybridAccession == indivAccession:
#               outHybridLST.append(line)
#               
#        for parvAccession in parvLST:
#           if parvAccession == indivAccession:
#               outParvLST.append(line)
#        
#        for mexAccession in mexLST:
#           if mexAccession == indivAccession:
#               outMexLST.append(line)
#    else: #writes the first lines needed for DIYABC program at beginning of script
#        out.write(line)                   
#
##compares wanted populations to the ones gathered from the files via the 
##arguments given by the bash script and writes them to a new file for lter use
#for hybrid in outHybridLST:
#    
#    hybridInfo = hybrid.strip().split("\t")
#    hybridAccPop = hybridInfo[0].split("&")
#    hybridAccession = hybridAccPop[1]
#
#    if hybridAccession == hybridPopName:
#        out.write(hybrid)
#
#for parv in outParvLST:
#    parvInfo = parv.strip().split("\t")
#    parvAccPop = parvInfo[0].split("&")
#    parvAccession = parvAccPop[1]
#    
#    if parvAccession == parvPopName:
#        out.write(parv)
#        
#for mex in outMexLST:
#    mexInfo = mex.strip().split("\t")
#    mexAccPop = mexInfo[0].split("&")
#    mexAccession = mexAccPop[1]
#    
#    if mexAccession == mexPopName:
#        out.write(mex)    
#
#
#zeaAllPop_DIYABC.close()
#out.close()