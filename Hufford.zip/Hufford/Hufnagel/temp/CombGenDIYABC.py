"""
This script creates a bash script to run the HybridData script by looking 
through the parv, mex and hybrid data files and combining all possible 
combinations of the three into a bash format output.
Created by Kathryn Kananen on 9/4/17
"""
import sys

dataFile = open(sys.argv[1]) #file from ZeaGenePopFormatter.py
out = open(sys.argv[2], 'w') #Bash script to be made

# gathers all information on desired populations (via FST) into the LSTs
parentLST = ["ZMX","ZMP"]
hybridLST = ["HCB", "HCP", "HSG"]

outLine = ""           
template = ("python ~/Documents/Hufford/Hufnagel/DIYABC/HybridData.py " +
            "DIYABC.snp ")
            
for hybrid in hybridLST:
    outFile = hybrid + "_ZMP_ZMXRun.snp "
    outLine = template + outFile + hybrid + " ZMP ZMX\n"
           
    out.write(outLine)     
        
    



#hybridLST = [] #stores possible Hybrids
#parvLST = [] #stores possible Parv
#mexLST = [] #stores possible Mex
#for line in dataFile:
#    #Skip all lines but data lines
#    if not line.startswith("Test") and not line.startswith("IND"):
#        lineIndiv = line.strip().split(" ")
#        
#      
#        accession = lineIndiv[6] 
#        # Seperates them into lists to combine later
#        if accession.startswith("ZMP"):
#            if not accession in parvLST:
#                parvLST.append(accession)
#        if accession.startswith("ZMX"):
#            if not accession in mexLST:
#                mexLST.append(accession)
#        else: 
#            if not accession in hybridLST:
#                hybridLST.append(accession)    
#        
##Change for dir changes.
#outLine = ""           
#template = ("python ~/Documents/Hufford/Hufnagel/DIYABC/HybridData.py " +
#            "DIYABC.snp ")
#
#count = 0  #should never go past 3 as only three var are present and to be 
## compared against each other.  One for every parv for every mex and every hyb        
#for hybrid in hybridLST:
#    for parv in parvLST:
#        for mex in mexLST:
#           if count == 3:
#               outFile = hybrid + "_" + parv + "_" + mex +"Run.snp "
#               outLine = template + outFile + hybrid + " " + parv + " " + mex + "\n"
#               
#               out.write(outLine)             
#               
#               outFile = ""
#               outLine = template + ""
#              
#               count = 0
#           count += 1

dataFile.close()
out.close()