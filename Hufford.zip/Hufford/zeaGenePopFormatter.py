"""
This script is designed to look though the ZeaAllInfo.14col.noMML and pick 
from each loci an arbatrally chosen allele converting it into a number system 
of hit counts.  1 being one found, 2 being two found, 9 
being missing data. The script will also format the file to have the commands 
needed for the DIYABC program to run its analysis on the file.

Created by Kathryn Kananen on 14/1/17
Continued work by David E. Hufnagel on 26/1/2017
"""
import sys, random


#This function adds a base pair to the list of present base pairs for a locus 
#when appropriate and does nothing otherwise.
def AddAllele(bp, listx, cnt):
    
    if bp == "N" or bp in listx[cnt] or len(listx[cnt]) == 2:
        return
        
    else:
        if listx[cnt] == [0]:
            listx[cnt] = [bp,]
            return
            
        elif len(listx[cnt]) == 1:
            listx[cnt].append(bp)
            return

#This function takes in all relevant data and outputs the population ID to use for DIYABC
def DeterminePop(acc, tax, hyb, popE):
    #non-hybrids
    if hyb != "hybrid" and (hyb == "parvHC" or hyb == "mexHC"):
        if tax == "Zea_mays_parviglumis":
            return "ZMP_%s" % (acc)
        elif tax == "Zea_mays_mexicana":
            return "ZMX_%s" % (acc)
        else:
            print("TAXONOMY ERROR 1!") #maize is excluded
            sys.exit()
    #hybrids
    elif hyb == "hybrid":
        if popE == "Central_Plateau":
            return "HCP_%s" % (acc)
        elif popE == "North_Balsas": #North_Balsas = Central Balsas
            return "HCB_%s" % (acc)
        elif popE == "South_Balsas": #South_Balsas = South Geurrero
            return "HSG_%s" % (acc)


ZeaAllInfo = open(sys.argv[1]) #ZeaAllInfo.14col.noMML.small.noMML.filt
out = open(sys.argv[2],'w')    #DIYABC input file with all data
bash = open(sys.argv[3], 'w')  #Bash file to run HybridData.py
numMarker = int(sys.argv[4])   #number of markers in the dataset


presentBases = [] #holds the present alleles at each locus, which starts as a list of 967 one-item lists each containing a zero
for i in range(numMarker):
    presentBases.append([0])

#Determine which base pairs exist at each biallelic locus
for line in ZeaAllInfo:
    # If the line is not a title line
    if not line.startswith("#"):  
        individual = line.strip().split("\t")
        indName = individual[0] #code name for individuals
        genos = individual[12].split(",") # only the SNP genotypes

        #iterate through all markers
        markerCnt = 0
        for pair in genos:
            alleleA = pair.split("_")[0]
            alleleB = pair.split("_")[1]

            AddAllele(alleleA, presentBases, markerCnt)
            AddAllele(alleleB, presentBases, markerCnt)

            markerCnt += 1

chosenLST = [] # holds the randomly chosen allele at each locus        
for pair in presentBases:
    chosen = random.choice(pair)
    chosenLST.append(chosen)

# writes the first line for the DIYABC to read Sex and MAF frequencies
# The tital can be change to fit the run
out.write("Test Run 1 for SNP <NM=1NF> <MAF=hudson>\n")
# Second line including count for autosomal diploids
ploidyLine = "IND     SEX  POP       "
ploidyLetter = 0 #Used for counting based on numMarker

# While the count is less than the numMarker add 'H'
while ploidyLetter <= numMarker-1:
    ploidyLine = ploidyLine + "A "
    ploidyLetter += 1 

    # Once at the end of the line finish and write line.
    if ploidyLetter == numMarker:
        ploidyLine = ploidyLine[:-1] + "\n" #cut off last space before adding endline
        out.write(ploidyLine)

outLine = "" #for SNP infomation
#runs through ZeaAllInfo again
ZeaAllInfo.seek(0) #resets the input to go through again
for line in ZeaAllInfo:
    #If the line is not a title line
    if not line.startswith("#"):
        individual = line.strip().split("\t")
        indName = individual[0] #code name for individuals
        genos = individual[12].split(",") #only the SNP genotypes
        accession = individual[2] #the accession for pop data
        taxon = individual[1]  #taxonomy data for pop data 
        hyb = individual[3]
        popExtra = individual[4]        

        pop = DeterminePop(accession, taxon, hyb, popExtra) #population to use for DIYABC starting with a useful 3-letter code (HCB=hybrid central balsas, HCP=hybrid central plateau, HSG=hybrid south geurrero, ZMP=high conf. non-hybrid parv, ZMX=high conf. non-hybrid mex)

        #outLine = indName + "&" + accession + "\t9\t" + taxon + "\t" #all info required
        outLine = "%s   M   %s   " % (indName, pop)
        
        #For every pair in a genos
        pairCnt = 0 #for knowing when to end the line & for matching locations
        for pair in genos:
            alleleA = pair.split("_")[0]
            alleleB = pair.split("_")[1]  
    
            chosenAllele = chosenLST[pairCnt] #grabs chosen allele from chosenLST    
            
            #Convert alleles into formatted output.
            if chosenAllele == alleleA and chosenAllele == alleleB:
                outLine = outLine + "2 "   
            elif chosenAllele == alleleA and chosenAllele != alleleB:
                outLine = outLine + "1 "
            elif chosenAllele != alleleA and chosenAllele == alleleB:
                outLine = outLine + "1 "
            elif alleleA == "N" and alleleB == "N":
                outLine = outLine + "9 "
            elif chosenAllele != alleleA and chosenAllele != alleleB:
                outLine = outLine + "0 "
            else:
                print("ERROR")

            pairCnt += 1
            
        # reset the line after outputting.   
        if pop != None:
            out.write(outLine + "\n")
            
#Section for making bash file            
# gathers all information on desired populations into the LSTs
parentLST = ["ZMX","ZMP"]
hybridLST = ["HCB", "HCP", "HSG"]

outLine = "" 
bash.write("#!/bin/bash\n\n") #declare this is a bash script          
template = ("python ~/Documents/Hufford/Hufnagel/DIYABC/HybridData.py " +
            sys.argv[2] + " ")
# makes an output for the bash file based on            
for hybrid in hybridLST:
    outFile = hybrid + "_ZMP_ZMXRun.snp "
    outLine = template + outFile + hybrid + " ZMP ZMX\n"
           
    bash.write(outLine)  


ZeaAllInfo.close()
out.close()
bash.close()